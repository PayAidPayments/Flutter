package com.example.payment_gateway_flutter_example

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
