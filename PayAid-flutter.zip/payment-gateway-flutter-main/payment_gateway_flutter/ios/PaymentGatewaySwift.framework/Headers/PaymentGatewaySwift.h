//
//  PaymentGatewaySwift.h
//  PaymentGatewaySwift
//
//  Created by Senthil Kumar Selvaraj on 03/05/21.
//

#import <Foundation/Foundation.h>

//! Project version number for PaymentGatewaySwift.
FOUNDATION_EXPORT double PaymentGatewaySwiftVersionNumber;

//! Project version string for PaymentGatewaySwift.
FOUNDATION_EXPORT const unsigned char PaymentGatewaySwiftVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <PaymentGatewaySwift/PublicHeader.h>


