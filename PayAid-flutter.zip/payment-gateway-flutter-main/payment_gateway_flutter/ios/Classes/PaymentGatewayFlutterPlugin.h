#import <Flutter/Flutter.h>

@interface PaymentGatewayFlutterPlugin : NSObject<FlutterPlugin>
@end
