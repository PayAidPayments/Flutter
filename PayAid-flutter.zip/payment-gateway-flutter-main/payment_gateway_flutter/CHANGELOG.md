## 1.0.0

* Updated initial setup